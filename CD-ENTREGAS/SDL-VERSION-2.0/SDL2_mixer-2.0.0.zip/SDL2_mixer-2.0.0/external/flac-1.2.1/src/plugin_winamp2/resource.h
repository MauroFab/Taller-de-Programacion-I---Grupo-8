//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDC_RESET                       3
#define IDD_CONFIG                      101
#define IDD_CONFIG_GENERAL              103
#define IDD_CONFIG_OUTPUT               104
#define IDD_INFOBOX                     105
#define IDC_ENABLE                      1000
#define IDC_ALBUM                       1001
#define IDC_LIMITER                     1002
#define IDC_COMMENT                     1002
#define IDC_PREAMP                      1003
#define IDC_YEAR                        1003
#define IDC_PA                          1004
#define IDC_TRACK                       1004
#define IDC_DITHER                      1005
#define IDC_DITHERRG                    1006
#define IDC_TO                          1008
#define IDC_SHAPE                       1009
#define IDC_TABS                        1009
#define IDC_TITLE                       1010
#define IDC_TAGZ_HELP                   1011
#define IDC_ARTIST                      1011
#define IDC_TAGZ_DEFAULT                1012
#define IDC_SEP                         1013
#define IDC_NAME                        1014
#define IDC_INFO                        1015
#define IDC_GENRE                       1017
#define IDC_REMOVE                      1020
#define IDC_UPDATE                      1021
#define IDC_ID3V1                       1030
#define IDC_RESERVE                     1032
#define IDC_BPS                         1036
#define IDC_ERRORS                      1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
